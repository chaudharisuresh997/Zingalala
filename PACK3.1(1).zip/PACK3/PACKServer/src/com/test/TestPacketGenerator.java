package com.test;

import com.metadata.PacketGenerator;
class A
{
String str;

public String getStr() {
	return str;
}

public void setStr(String str) {
	this.str = str;
}

public A(String str) {
	super();
	this.str = str;
}
public void do1()
{
System.out.println(""+getStr());	
}
}
public class TestPacketGenerator {
	public static void main(String[] args) {
		A pGen=new A("Shiv is great");
		
		//pGen.dataToBSent="Its a test";
		pGen.do1();
	}


}
