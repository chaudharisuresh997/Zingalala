package com.recovery;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.logging.Logger;
public class CheckSumReceiver {
public static final Logger LOGGER=Logger.getLogger(CheckSumReceiver.class.getName());
		  public static void receiveMissingChunkSeq(){  
				LOGGER.info("receiveMissingChunkSeq");
		    DatagramSocket ds = null;
			try {
				ds = new DatagramSocket(3002);
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		    byte[] buf = null;
		    
		    	buf=new byte[1024];
		    DatagramPacket dp = new DatagramPacket(buf, 1024);
		    
		    try {
				ds.receive(dp);
				String missingChunkNumber=new String(dp.getData(),0,buf.length);
				LOGGER.info("Packet Received"+missingChunkNumber);
				new SendMissingChunk().sendChunkAgain();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		 
		    
		    //ds.close();  
	  }  
 

}
