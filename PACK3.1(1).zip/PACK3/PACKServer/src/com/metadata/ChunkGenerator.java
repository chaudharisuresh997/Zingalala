package com.metadata;

import com.schema.PackSchema;

public class ChunkGenerator {
public static int CHUNKSYQUENCE_NO;
	public static String getChunkStart()
	{
		return PackSchema.ChunkStart;
		
	}
	public static String getChunkEnd()
	{
		return PackSchema.ChunkEND;
		
	}
	public static int getChunkSeqNumber()
	{
		return CHUNKSYQUENCE_NO;
		
	}
	public static int getNextChunkSeqNumber()
	{
		return CHUNKSYQUENCE_NO+=1;
		
	}

}
