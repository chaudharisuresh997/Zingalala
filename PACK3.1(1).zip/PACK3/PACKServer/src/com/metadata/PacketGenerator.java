package com.metadata;

public class PacketGenerator {
	public PacketGenerator() {
		
	}
	public PacketGenerator(String dataToBSent) {
		super();
		this.dataToBSent = dataToBSent;
	}
	public String dataToBSent;//"Hi I am a very good guy";
	public String getDataToBSent() {
		return dataToBSent;
	}
	public void setDataToBSent(String dataToBSent) {
		this.dataToBSent = dataToBSent;
	}
	public static int localpackCounter=0;
	public String [] packets;//=this.getDataToBSent().split(" ");
public String generatePackets()
{
	String onePacket="";
	
	if(localpackCounter!=(packets.length-1))
	{
		onePacket=packets[localpackCounter];
		localpackCounter+=1;
	}
	return onePacket;
}

}
