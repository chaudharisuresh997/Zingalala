package com.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.metadata.ChunkGenerator;
import com.metadata.PacketGenerator;
import com.schema.PackSchema;

import java.util.logging.Level;
import java.util.logging.Logger;
public class SenderChunk {
	private final static Logger LOGGER = Logger.getLogger(SenderChunk.class.getName());
	public SenderChunk()
	{
	 //LOGGER.setLevel(Level.SEVERE);
	}
	public List<String> packs=new ArrayList<String>();
	public PacketGenerator packGen=new PacketGenerator();
	
	int packCounter=0;//used for creating chunk start and end
	int packDataCounter=0;//actual data counter
	
	public void initChunk(){
		packGen.setDataToBSent("HI SHIV");
		packGen.packets=packGen.getDataToBSent().split(" ");
		while(packDataCounter!=(packGen.packets.length-1))
		{
		if(PackSchema.CHUNKSIZE==packCounter)
		{
			String data=ChunkGenerator.getChunkEnd()+""+ChunkGenerator.getChunkSeqNumber();
			//packs.add(PackSchema.getNOOFPACKETSCOUNTER(),data);
		packs.add(data);
			//packs.add(ChunkGenerator.getChunkStart()+""+ChunkGenerator.getNextChunkSeqNumber());
			packCounter=0;
		}
		else if(packCounter==0)
		{
			String data=ChunkGenerator.getChunkStart()+""+ChunkGenerator.getNextChunkSeqNumber();
			//int counter=PackSchema.getNOOFPACKETSCOUNTER();
		//	packs.add(counter,data);
			packs.add(data);
			
			packCounter+=1;
			
			
		}
		else
		{
			//int counter=PackSchema.getNOOFPACKETSCOUNTER();
		String data=packGen.generatePackets();
			//packs.add(counter,data);
		LOGGER.info("payload added "+data);
		packs.add(data);
			packCounter+=1;
			packDataCounter+=1;
		}
		
	}
		packs.add(PackSchema.MSGEND);//This denotes ends of message payload
	}
	//TO resend the missing packets of the specified chunks
	public void initChunkForMissingChunk(){
		packGen.dataToBSent="THIS IS NEW SHIV";
		packGen.packets=packGen.dataToBSent.split(" ");
		while(packDataCounter!=(packGen.packets.length-1))
		{
		if(PackSchema.CHUNKSIZE==packCounter)
		{
			String data=ChunkGenerator.getChunkEnd()+""+ChunkGenerator.getChunkSeqNumber();
			//packs.add(PackSchema.getNOOFPACKETSCOUNTER(),data);
		packs.add(data);
			//packs.add(ChunkGenerator.getChunkStart()+""+ChunkGenerator.getNextChunkSeqNumber());
			packCounter=0;
		}
		else if(packCounter==0)
		{
			String data=ChunkGenerator.getChunkStart()+""+ChunkGenerator.getNextChunkSeqNumber();
			//int counter=PackSchema.getNOOFPACKETSCOUNTER();
		//	packs.add(counter,data);
			packs.add(data);
			
			packCounter+=1;
			
			
		}
		else
		{
			//int counter=PackSchema.getNOOFPACKETSCOUNTER();
		String data=packGen.generatePackets();
			//packs.add(counter,data);
		LOGGER.info("payload added "+data);
		packs.add(data);
			packCounter+=1;
			packDataCounter+=1;
		}
		
	}
		packs.add(PackSchema.MSGEND);//This denotes ends of message payload
		packCounter=0;//as send chunk is getting only last element
	}
	public String sendChunk()
	{
		String packet = "";
		if(packCounter<packs.size())
		{
			packet=packs.get(packCounter);
			
			packCounter++;
		}
		return notNull(packet);
	}
	private String notNull(String packet) {
		String p;
		if(packet!=null)
		{
			p=packet;
		}
		else{
			p="";
		}
		
		return p;
	}
	
	public static void main(String[] args) {
		SenderChunk s=new SenderChunk();
		s.initChunk();
	}
}
