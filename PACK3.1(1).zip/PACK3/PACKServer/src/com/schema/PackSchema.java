package com.schema;

public class PackSchema {
public static int PACKCOUNTER=0;
public static int CHUNKSIZE=2;
public static String ChunkStart="START";
public static String ChunkEND="END";
public static int NOOFPACKETSCOUNTER=0;
public static String MSGEND="ENDM";
public static int getNOOFPACKETSCOUNTER() {
	return NOOFPACKETSCOUNTER+=1;
}
public static void setNOOFPACKETSCOUNTER(int nOOFPACKETSCOUNTER) {
	NOOFPACKETSCOUNTER = nOOFPACKETSCOUNTER;
}
}
