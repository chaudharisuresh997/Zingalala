import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test {
	public static void main(String[] args) {
		
		String str = "Hello123";
		   Matcher matcher = Pattern.compile("\\d+").matcher(str);

	        if (!matcher.find())
	            throw new NumberFormatException("For input string [" + str + "]");



System.out.println(Integer.parseInt(matcher.group()));				

	
	}
	
}
