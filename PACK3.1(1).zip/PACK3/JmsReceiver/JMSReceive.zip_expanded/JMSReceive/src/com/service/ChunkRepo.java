package com.service;

import java.net.DatagramPacket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

import com.recovery.AckMissingChunk;
import com.schema.PackSchema;
@Service("chunkRepo")
public class ChunkRepo {
	private final static Logger LOGGER = Logger.getLogger(ChunkRepo.class.getName());
	List<String> payLoads=new ArrayList<>();
	List<String> chunkStore=new ArrayList<>();
	public void processChunk(DatagramPacket packet)
	{LOGGER.info("IN side processChunk");
		String payLoad=extractPayLoad(packet);
		addToChunkSore(payLoad);
		
	}
	public String extractPayLoad(DatagramPacket packet)
	{
		return new String(packet.getData(),0,packet.getData().length);
	}
	public void addToChunkSore(String payLoad)
	{	LOGGER.info("IN side addToChunkSore");
		if(payLoad!="ENDM")
		{
			chunkStore.add(payLoad);
		}
		else{
			streamPacketsFromChunkRepo();
		}
	}
	public void showChunks()
	{	
		
		System.out.println("Your ChunkStore");
		for(String packet:chunkStore)
		{
			//DemoMain main=new DemoMain();
			//main.sendMsgToQueue(packet);
		}
	}
	public void streamPacketsFromChunkRepo()
	{	LOGGER.info("IN side streamPacketsFromChunkRepo");
			Iterator<String> itPackets=chunkStore.iterator(); 
		while(itPackets.hasNext())
		{
			String payLoad=itPackets.next();
			analyZeBoundaries(payLoad);
		}
		LOGGER.info("SENDING MISSING CHUNK METADATA");
		try {
			AckMissingChunk.sendReqForMissingChunk("2");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void analyZeBoundaries(String payLoad) {
		if(payLoad.contains(PackSchema.ChunkStart))
		{
			Matcher matcher = Pattern.compile("\\d+").matcher(payLoad);
			LOGGER.info(payLoad);
	        if (!matcher.find())
	            throw new NumberFormatException("For input string [" + payLoad + "]");
	        
	        System.out.println(Integer.parseInt(matcher.group()));			
		}
		else if(payLoad.contains(PackSchema.ChunkStart))
		{	LOGGER.info(payLoad);
			Matcher matcher = Pattern.compile("\\d+").matcher(payLoad);

	        if (!matcher.find())
	            throw new NumberFormatException("For input string [" + payLoad + "]");
	        
	        System.out.println(Integer.parseInt(matcher.group()));			

		}
		else if(payLoad.contains(PackSchema.MSGEND))
		{	LOGGER.info(payLoad);
			//here you should start checksum
		}
		else
		{
			LOGGER.info(payLoad);
			//This is your actual payload
			payLoads.add(payLoad);
		}
		
	}
}
