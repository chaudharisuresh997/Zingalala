package com.recovery;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.logging.Logger;

import com.service.ChunkRepo;

public class AckMissingChunk {
	private final static Logger LOGGER = Logger.getLogger(ChunkRepo.class.getName());
	//Sends Missing Chunk
	 public static void sendReqForMissingChunk(String chunkSeqNumber) throws Exception {
		  LOGGER.info("Sendng Missing Seq Number");
		    DatagramSocket ds = new DatagramSocket();  
		
		     
		    
		    InetAddress ip = InetAddress.getByName("127.0.0.1");  
		    while(true)
		    {
		    	 String str = chunkSeqNumber;
		    	 if(str.equalsIgnoreCase(""))
		    	 {
		    		 
		    	 }
		    DatagramPacket dp = new DatagramPacket(str.getBytes(), str.length(), ip, 3002);  
		    ds.send(dp);
		    LOGGER.info(" Missing Seq Number Sent"+str);
		    }
		   
		   
		  }  
}
