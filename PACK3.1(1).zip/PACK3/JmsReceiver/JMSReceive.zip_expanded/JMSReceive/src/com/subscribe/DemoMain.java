package com.subscribe;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
 
 
public class DemoMain {
 
  public static void main(String[] args) {
	  /*BrokerService broker = new BrokerService();
	  
	// configure the broker
	try {
		broker.addConnector("tcp://localhost:61616");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
	try {
		broker.start();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/

    // init spring context
	  GenericXmlApplicationContext ctx=new GenericXmlApplicationContext();  
	     ctx.load("classpath:app-context.xml");  
	      ctx.refresh();  

   /* ApplicationContext ctx = new ClassPathXmlApplicationContext("app-context.xml");
         ctx.refresh();*/
    // get bean from context
   // JmsMessageSender jmsMessageSender = (JmsMessageSender)ctx.getBean("jmsMessageSender");
         
    // send to default destination 
   // jmsMessageSender.send(args);
   //      
    // send to a code specified destination
   // Queue queue = new ActiveMQQueue("AnotherDest");
    //jmsMessageSender.send(queue, "hello Another Message");
   while(true){
	   
   }
  
    // close spring application context
  //  ((ClassPathXmlApplicationContext)ctx).close();
  }
 
}
