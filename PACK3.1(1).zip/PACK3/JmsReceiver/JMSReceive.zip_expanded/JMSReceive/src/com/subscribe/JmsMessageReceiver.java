package com.subscribe;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;

import com.schema.PackSchema;
import com.service.ChunkRepo;

public class JmsMessageReceiver implements MessageListener {

	@Autowired
ChunkRepo chunkRepo;
    public ChunkRepo getChunkRepo() {
	return chunkRepo;
}
public void setChunkRepo(ChunkRepo chunkRepo) {
	this.chunkRepo = chunkRepo;
}

	public void onMessage(final Message message) {
    	TextMessage msg=(TextMessage)message;
    	try {
    		chunkRepo.addToChunkSore(msg.getText());
    		if(msg.getText().equalsIgnoreCase(PackSchema.MSGEND))
    		{
    			System.out.println("MSG END********** arrived");
    		chunkRepo.streamPacketsFromChunkRepo();
    		}
			//System.out.println(""+msg.getText());
		} catch (JMSException e) {
			
			e.printStackTrace();
		}
       /* if (message instanceof String) {
            final String mapMessage = (String) message;
            
        }*/
    }

}