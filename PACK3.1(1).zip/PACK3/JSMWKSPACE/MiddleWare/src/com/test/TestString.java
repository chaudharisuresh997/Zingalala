package com.test;

public class TestString {

	public static void main(String[] args) {
String end="END";
if(end.equalsIgnoreCase("END"))
{
	System.out.println("EQUAL");
}else{
	System.out.println("EQUAL!");
}

	}

}
