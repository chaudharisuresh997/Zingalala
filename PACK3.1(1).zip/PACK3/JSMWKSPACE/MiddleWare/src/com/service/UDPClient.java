package com.service;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;


public class UDPClient {

  public static void main(String[] args) throws Exception {
	  ChunkRepo chunkRepo=ModelFactory.GetChunkrepo();
    DatagramSocket s = ModelFactory.createSocket();
    byte[] buf = new byte[1000];
    DatagramPacket dp = ModelFactory.createNewPacket();

    InetAddress hostAddress = ModelFactory.calcHostAddress();
    while (true) {
      BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
      String outMessage = stdin.readLine();

      if (outMessage.equals("bye")){
    	  chunkRepo.showChunks();
        break;
      }
      String outString = "Client say: " + outMessage;
      buf = outString.getBytes();

      DatagramPacket out = new DatagramPacket(buf, buf.length, hostAddress, 61887);
      s.send(out);

      s.receive(dp);
      chunkRepo.processChunk(dp);
      
      String rcvd = "rcvd from " + dp.getAddress() + ", " + dp.getPort() + ": "
          + new String(dp.getData(), 0, dp.getLength());
      System.out.println(rcvd);
    }
  }
}