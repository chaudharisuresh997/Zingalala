package com.service;

import java.net.DatagramPacket;
import java.util.ArrayList;
import java.util.List;

import com.publisher.DemoMain;

public class ChunkRepo {
	
	List<String> chunkStore=new ArrayList<String>();
	
	public void processChunk(DatagramPacket packet)
	{
		String payLoad=extractPayLoad(packet);
		addToChunkSore(payLoad);
		
	}
	public String extractPayLoad(DatagramPacket packet)
	{
		return new String(packet.getData(),0,packet.getData().length);
	}
	public void addToChunkSore(String payLoad)
	{	
		if(true)
		{
			showChunks();
		}
		else
		{
			chunkStore.add(payLoad);
		}
		
	}
	public void showChunks()
	{	
		
		System.out.println("Your ChunkStore");
		for(String packet:chunkStore)
		{
			DemoMain main=new DemoMain();
			main.sendMsgToQueue(packet);
		}
	}
}
