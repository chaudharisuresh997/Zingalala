package com.service;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import com.schema.Struct;

public class ModelFactory {
	static int PORT=4000;
	 static byte[] buf = new byte[1000];
	public static DatagramPacket createNewPacket()
	{
		return new DatagramPacket(buf, Struct.PACK_SIZE);
	}
	public static DatagramSocket createSocket()
	{
		DatagramSocket socket=null;
		try {
			socket =new DatagramSocket(PORT);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return socket;
	}
	public static InetAddress calcHostAddress()
	{
		InetAddress addr=null;
		try {
			addr= InetAddress.getByName("localhost");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return addr;
	}
	public static ChunkRepo GetChunkrepo()
	{
		return new ChunkRepo();
	}

	
}
