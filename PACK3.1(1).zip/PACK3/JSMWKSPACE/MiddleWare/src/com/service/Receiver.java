package com.service;
import java.net.*;

import com.publisher.DemoMain;  
public class Receiver {
  public static void main(String[] args) throws Exception {  
    DatagramSocket ds = new DatagramSocket(3000);  
    byte[] buf = null;
    while(true)
    {
    	buf=new byte[1024];
    DatagramPacket dp = new DatagramPacket(buf, 1024);
   ds.setReuseAddress(true);
    ds.receive(dp);  
    
    DemoMain main=new DemoMain();
	main.sendMsgToQueue(new String(dp.getData(),0,dp.getLength()));
    /*ChunkRepo repo=new ChunkRepo();
    repo.processChunk(dp);*/
    System.out.println("Got Packet");
    }
    //ds.close();  
  }  
} 
