package com.schema;

public class Struct {
public static int PACK_SIZE=1000;
}
