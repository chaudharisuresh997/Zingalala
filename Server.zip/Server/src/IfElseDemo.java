
public class IfElseDemo {

	public static void main(String[] args) {
		int percentage=75;
		if(percentage>75)
		{
			System.out.println("Distinction");
		}
		else if(percentage>60)
		{
			System.out.println("First Class");
		}
		else if(percentage>40)
		{
			System.out.println("Second Class");
		}
		else if (percentage>35) {
			System.out.println("Pass Class");	
		}		
		else
		{
			System.out.println("Fail");
		}

	}

}
/*  OutPut
 * First Class 
 */