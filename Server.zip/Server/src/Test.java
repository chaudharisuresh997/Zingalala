import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

class CountNoOfOnes
{List<Integer> result=new ArrayList<Integer>();
int index=0;
int occurance=0;

	public void convertToBinary(int number)
	{
		
		while(number>0)
		{
		int rem=number%2;
		 number=number/2;
		 result.add(rem);
		}
		Collections.reverse(result);
		
		for(int i=0;i<result.size();i++)
		{
			int marker=i;
			if(marker!=(result.size()-1))
			{
			//int next=marker++;
				marker++;
			
				if(result.get(i).toString().equalsIgnoreCase(result.get(marker).toString()))		
				{
					if(result.get(i).toString().equalsIgnoreCase("1"))
					{
						
					occurance+=2;
					i++;
					marker++;
					
					}
				
				}
			}
			//if((Integer.compare(result.get(i),result.get(marker)))>1)
			
		}
		System.out.println("Occurance are"+occurance);
	}
	
}
public class Test {

	public static void main(String[] args) {
		new CountNoOfOnes().convertToBinary(83918840);

	}

}
