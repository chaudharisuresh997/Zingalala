
public class StringDemo {

	public static void main(String[] args) {
		//Declare the String.Assign Value. 
		String stringObj="I am Program";

		//Print Char at 0th index
		System.out.println("Char At 0th Index is==>"+stringObj.charAt(0));
		System.out.println("UniCode At 0th Index is==>"+stringObj.codePointAt(0));
		boolean checkEqual=false;
		if(stringObj.compareTo("I am Program")==1)
		{
			System.out.println("Equal");
		}
		else
		{
			System.out.println("Not Equal");
		}
		System.out.println("Char At 0th Index is==>"+stringObj.substring(0, 4));
		System.out.println("Gives index of Char S==>"+stringObj.indexOf('P'));
		System.out.println("Gives starting index of String==>"+stringObj.indexOf("Program"));
		System.out.println("Intern==>"+stringObj.intern());//checks whether specified string
		
		//already present in the string pool.
		System.out.println("gives string starting from speciied index==>"+stringObj.substring(3));
		System.out.println("UpperCase==>"+stringObj.toUpperCase());
		System.out.println("COncat==>"+stringObj.concat("Of Java"));
		
		String[] splits=new String[4];
		splits=stringObj.split(" ");
		System.out.println("Splitted String is "+splits[1]);
		
		
		
	}

}
/**
 * 		OUTPUT
 * 		Char At 0th Index is==>I
		UniCode At 0th Index is==>73
		Not Equal
		Char At 0th Index is==>I am
		Gives index of Char S==>5
		Gives starting index of String==>5
		Intern==>I am Program
		gives string starting from speciied index==>m Program
		UpperCase==>I AM PROGRAM
		COncat==>I am ProgramOf Java
		Splitted String is am

 * 
 */

