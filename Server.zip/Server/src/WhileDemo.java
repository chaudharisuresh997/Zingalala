
public class WhileDemo {

	public static void main(String[] args) {
	int myBankBalance=5000;
	while(myBankBalance<20000)
	{
		System.out.println("I will work because now my balance is"+myBankBalance);
		myBankBalance+=4000;//short hand notation this means myBankBalance=myBankBalance+4000; 
	}
	System.out.println("Now my Bank Balance is "+myBankBalance+" I will not work :P");

	}

}
/*Output
I will work because now my balance is5000
I will work because now my balance is9000
I will work because now my balance is13000
I will work because now my balance is17000
Now my Bank Balance is 21000 I will not work :P
*/