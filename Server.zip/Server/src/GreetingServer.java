import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Random;

class Util
{HashMap<String,Integer> list=null;
	public double makeHandShake()
	{  
		return new Random().nextDouble();
	}


}
public class GreetingServer
{
  public static void main(String[] args) throws Exception
  {
	  int msgCount=0;
	  boolean handShake=false;
      ServerSocket sersock = new ServerSocket(3000);
      System.out.println("Server  ready for chatting");
      Socket sock = sersock.accept( );                          
                              // reading from keyboard (keyRead object)
      BufferedReader keyRead = new BufferedReader(new InputStreamReader(System.in));
	                      // sending to client (pwrite object)
      OutputStream ostream = sock.getOutputStream(); 
      PrintWriter pwrite = new PrintWriter(ostream, true);
 
                              // receiving from server ( receiveRead  object)
      InputStream istream = sock.getInputStream();
      BufferedReader receiveRead = new BufferedReader(new InputStreamReader(istream));
 
      String receiveMessage, sendMessage;               
      while(true)
      {
        if((receiveMessage = receiveRead.readLine()) != null)  
        {	msgCount+=1;
        	if(msgCount==1)
        	{
        		if(receiveMessage.equalsIgnoreCase("zingalala"))
        		{
        			handShake=true;
        		System.out.println("HandShake Success");
        		}
        		else
        		{
        			System.out.println("ABORT");
        		}
        		
        		
        	}
        	System.out.println(receiveMessage);
                    
        }
        	if(handShake){
        				sendMessage = keyRead.readLine();
        				pwrite.println(sendMessage);             
        				pwrite.flush();
        		}
      }               
    }                    
}                   
