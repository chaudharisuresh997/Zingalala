
public class ArraysDemo {
public static void main(String[] args) {
	String[] arrayStr=new String[4];
	arrayStr[0]="Shiv";
	
	//to ghet the size arrayObj.length
	System.out.println(""+arrayStr.length);
	//Can you find S letter in the array
	
	if(arrayStr[0].contains("S"))
	{
		
		System.out.println("Yes Letter Found");
	}
	else{ System.out.println("Letter Not Found");}
	
}
}
