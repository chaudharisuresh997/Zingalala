
public class ForLoopDemo {

	public static void main(String[] args) {
		for(int i=0;i<=5;i++)
		{
			System.out.println(""+i);
		}
	}

}
/*OutPut
0
1
2
3
4
5
*/