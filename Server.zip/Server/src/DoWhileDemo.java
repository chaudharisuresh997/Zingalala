
public class DoWhileDemo {

	public static void main(String[] args) {
		boolean doYouhaveTicket=false;
	do {
	System.out.println("Checking ticket at theater but i dont have ticket");
		
	} while (doYouhaveTicket);		
	System.out.println("I was kicked off from theater as i was not having ticket.");
	}

}
/*
	Output
Checking ticket at theater but i dont have ticket
I was kicked off from theater as i was not having ticket.
*/