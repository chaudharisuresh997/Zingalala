
public class StringBufferDemo {
public static void main(String[] args) {
	StringBuffer buffer=new StringBuffer();
	buffer.append("First");
	buffer.append(" Second");

	System.out.println("Second Located at index==>"+buffer.indexOf("Second"));
	System.out.println("Last Occurance of letter e is=>"+buffer.lastIndexOf("e"));
	System.out.println("First Occurance of letter e is=>"+buffer.indexOf("e"));
	buffer.insert(0, 2.3f);
	System.out.println("after inserting==>"+buffer);
	System.out.println("Capacity is ==>"+buffer.capacity());
	System.out.println("Length is ==>"+buffer.length());
	System.out.println(""+buffer.delete(0, 3));
	System.out.println("I am reverse==>"+buffer.reverse());

}
}
