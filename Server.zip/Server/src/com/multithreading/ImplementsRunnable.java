package com.multithreading;
class DoTask implements Runnable
{

	@Override
	public void run() {
		System.out.println("HI i am thread created using runnable");
		
	}
}
public class ImplementsRunnable {

	public static void main(String[] args) {
		//Create instance of class which implements Runnable
		DoTask doObj=new DoTask();
//create Thread instance and pass runnable instance as arguement
		Thread threadObj=new Thread(doObj);
		
		threadObj.start();
	}

}
