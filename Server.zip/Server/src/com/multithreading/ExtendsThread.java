package com.multithreading;

import java.util.ArrayList;
import java.util.List;

class PrintTable extends Thread
{
	List<String> arr;
	
	public PrintTable(List<String> array) {
		this.arr=array;
	}

	public void run()
	{
		synchronized (arr) {
			for(int i=0;i<6;i++)
			{
				try {
				Thread.sleep(4);
				} catch (InterruptedException e) {
				e.printStackTrace();
				}
				arr.add(i,""+i);
				System.out.println(""+arr.get(i)+""+this.getName());
			}	
		}
		
	}
}
public class ExtendsThread {
	public static void main(String[] args) {
		List<String> array=new ArrayList<String>();
		
		PrintTable table=new PrintTable(array);
		table.start();
		
		
		PrintTable table1=new PrintTable(array);
		
		table1.start();
		try {
			table.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		PrintTable table2=new PrintTable(array);
		table2.start();
		try {
			table1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
}
/**
 *
 * OutPut
0Thread-1
1Thread-1
2Thread-1
3Thread-1
4Thread-1
5Thread-1
0Thread-0
1Thread-0
2Thread-0
3Thread-0
4Thread-0
5Thread-0
0Thread-2
1Thread-2
2Thread-2
3Thread-2
4Thread-2
5Thread-2


 */

