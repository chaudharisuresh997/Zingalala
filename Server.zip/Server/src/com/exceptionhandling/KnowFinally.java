package com.exceptionhandling;

public class KnowFinally {

	public static void main(String[] args) {
		int myValue=5;
	try{
		myValue=6;
		int result=myValue/0;
		System.out.println(""+myValue);
		
		}
		catch (Exception e) {
			System.out.println("I visited Catch");
			myValue=7;
		}
		finally {
			System.out.println("I visited Finally");
			myValue=10;
		}
System.out.println("Final Result "+myValue);
	}

}
/**OUTPUT
 * I visited Catch
   I visited Finally
   Final Result 10

 * 
 */

