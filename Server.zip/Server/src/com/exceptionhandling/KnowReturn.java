package com.exceptionhandling;

public class KnowReturn {
static void print(int number)
{System.out.println(""+number);
	}
	public static void main(String[] args) {
		int myValue;
		try{
			myValue=6;
			
		//	System.out.println(""+myValue);
			return;
			}
			catch (Exception e) {
				System.out.println("I visited Catch");
				myValue=7;
			}
			finally {
				myValue=10;
				System.out.println("I visited Finally");
				print(myValue);				
			}

	}

}
/**
 * Output
 * I visited Finally
	10

 */

