package com.exceptionhandling;

public class ExceptionHirarchyUnReachableDemo {

	public static void main(String[] args) {

		try{
			System.out.println(""+(8/0));
		}catch(Exception ex)
		{
			System.out.println("Exception is "+ex.getMessage() );
		}
	/*	catch(ArithmeticException ex) 
		{
			System.out.println("Arithmatic Exception"+ex.getMessage() );
		}*/
//At Line 13:Unreachable catch block for ArithmeticException.
//		It is already handled by the catch block for Exception
	}

}
