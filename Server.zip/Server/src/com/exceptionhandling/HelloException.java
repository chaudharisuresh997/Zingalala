package com.exceptionhandling;

public class HelloException {
public static void main(String[] args)
{
System.out.println(""+(1/0));
//This exception divide by zero will never execute below line
//and abnormaly exits the whole program.
System.out.println("Hello World");
//instead we will try to catch this exception print it and also execite rest of the line 
//Please see HelloException2
}
}
