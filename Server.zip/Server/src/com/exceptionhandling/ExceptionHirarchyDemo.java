package com.exceptionhandling;

public class ExceptionHirarchyDemo {

	public static void main(String[] args) {

		try{
			System.out.println(""+(8/0));
		}catch(ArithmeticException ex) 
		{
			System.out.println("Arithmatic Exception"+ex.getMessage() );
		}catch(Exception ex)
		{
			System.out.println("Exception is "+ex.getMessage() );
		}

	}

}
