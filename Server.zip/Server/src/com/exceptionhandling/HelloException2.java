package com.exceptionhandling;

public class HelloException2 {
	public static void main(String[] args)
	{
		try{
			System.out.println(""+(1/0));
		}catch(ArithmeticException e)
		{
			System.out.println(""+e.getMessage());
		}
		//This exception divide by zero handled now so Hellow World 
		//is executed 
		System.out.println("I will be executed as exception is handled now Hello World");
		
	}
}
