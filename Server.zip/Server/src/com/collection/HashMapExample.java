package com.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashMapExample {

	public static void main(String[] args) {
		Map<String,String> mapObj=new HashMap<>();
		
		mapObj.put("old", "1");
		mapObj.put("old", "2");//will replace 1 by 2 as duplicate keys not allowed.
		
		//iterateAndPrint(mapObj);
		
		//Output :Key is old Value is 2
		mapObj.put("latest","5");//hashMap will not maintain insertion order.
		mapObj.put("new","3");
		mapObj.put(null,null);
		mapObj.put(null,null);//HashMap can have only one null key and many values as null
		System.out.println("************Before Removing************");
		iterateAndPrint(mapObj);
		
		mapObj.remove("latest");
		
		System.out.println("********After Removing************");
		iterateAndPrint(mapObj);

		
		
	}

	private static void iterateAndPrint(Map<String, String> mapObj) {
		Set<String> keys=mapObj.keySet();
		System.out.println();
		for(String key:keys)
		{
			System.out.println("Key is "+key+"| Value is "+mapObj.get(key));
		}
		System.out.println();
	}

}
/*************Before Removing************

Key is null| Value is null
Key is new| Value is 3
Key is old| Value is 2
Key is latest| Value is 5

********After Removing************

Key is null| Value is null
Key is new| Value is 3
Key is old| Value is 2

*/
