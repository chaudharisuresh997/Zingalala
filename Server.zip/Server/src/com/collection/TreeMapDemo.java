package com.collection;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
/**
 * 1.TreeMap is implmentation of SortedMap<I>
 */
public class TreeMapDemo {

	public static void main(String[] args) {

		Map<Integer,String> treeObj=new TreeMap<>();
		treeObj.put(1, "Sam");
		treeObj.put(1000, "Zarin");
		treeObj.put(5, "Yak");
		treeObj.put(100, "Peter");
		
		Set<Integer> keySet=treeObj.keySet();
		System.out.println();
		System.out.println("Before Remove");
		for(Integer oneKey:keySet)
		{
			System.out.println("key=>"+oneKey+" Value is=>"+treeObj.get(oneKey));
		}
		System.out.println();
		
		treeObj.remove(5);//removing element with key 5
		System.out.println("after Remove");
		
		iterateAndPrint(treeObj);	
		
		/************ADD DUPLLICATES****************/
		System.out.println("After Adding Duplicate");
		treeObj.put(100,"Peter");
		iterateAndPrint(treeObj);
		
		/******ADD NULL *******************/
		System.out.println("After Adding NULL");
		treeObj.put(null,null);
		iterateAndPrint(treeObj);
		
	}
	public static void iterateAndPrint(Map treeMapObj)
	{
		Set<Integer> keySet=treeMapObj.keySet();	
		for(Integer oneKey:keySet)
		{
			System.out.println("key=>"+oneKey+" Value is=>"+treeMapObj.get(oneKey));
		}
	}
	
	/******************OUTPUT******************************/
	/*Before Remove
	key=>1 Value is=>Sam
	key=>5 Value is=>Yak
	key=>100 Value is=>Peter
	key=>1000 Value is=>Zarin

	after Remove
	key=>1 Value is=>Sam
	key=>100 Value is=>Peter
	key=>1000 Value is=>Zarin
	After Adding Duplicate
	key=>1 Value is=>Sam
	key=>100 Value is=>Peter
	key=>1000 Value is=>Zarin
	After Adding NULL
	Exception in thread "main" java.lang.NullPointerException
		at java.util.TreeMap.put(TreeMap.java:563)
		at com.collection.TreeMapDemo.main(TreeMapDemo.java:58)*/

			
}
