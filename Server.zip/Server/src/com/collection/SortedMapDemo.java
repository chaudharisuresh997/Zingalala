package com.collection;

import java.util.Map;

public class SortedMapDemo {

	public static void main(String[] args) {
		
	//See TreeMap as it is implementation of SortedMap.
		
	}

}
