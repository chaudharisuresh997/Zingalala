package com.collection;

import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.PriorityBlockingQueue;

public class QueueDemo {

	public static void main(String[] args) {
Queue<String> queueObj=new PriorityBlockingQueue<>();
queueObj.add("Shiv"); queueObj.add("A");
System.out.println("POLL() Removes and shows element from the haed of queue"+queueObj.poll());
System.out.println("PEEK() Will display element but won't remove"+queueObj.peek());
System.out.println("ADDS element and returns boolean "+queueObj.offer("UI"));
iterateAndPrint(queueObj);

	}
	private static void iterateAndPrint(Queue listObj) {
		Iterator<String> iteratorObj=listObj.iterator();
		while(iteratorObj.hasNext())
		{
			System.out.println(""+iteratorObj.next());
		}
	}
}
