package com.collection;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		Set<String> linkedHashSet=new LinkedHashSet<>();
		linkedHashSet.add("zak");
		linkedHashSet.add("ak");
		linkedHashSet.add("k");
		
		linkedHashSet.add("k");
		linkedHashSet.add("k");
		System.out.println("Output After Adding duplicates");
		iterateAndPrint(linkedHashSet);//repeated elements will be removed.
		//order of elements is preserved.
		
		System.out.println("Output after adding null");
		linkedHashSet.add(null);//check if null is entertained.
		iterateAndPrint(linkedHashSet);//NUll ALLOWED
		
	}
	public static void iterateAndPrint(Set linkedHashSet)
	{
		
	Iterator<String> it=linkedHashSet.iterator();
			
		while(it.hasNext())
		{
			System.out.println("Value=>"+it.next());
		}
	}

}
/**
 * 		Output
 * 		Output After Adding duplicates
			
			Value=>zak
			Value=>ak
			Value=>k
		
		Output after adding null
			
			Value=>zak
			Value=>ak
			Value=>k
			Value=>null

 * 
 */

