package com.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
 * Rules:
 * 1.Maintains the order 
 * 2.Does not ommit nulls
 * 3.Does not give Null PoointerException at all means accepts null also
 * 
 * 
 *
 */
public class ArrayListDemo {

	public static void main(String[] args) {
	List<String> listObj=new ArrayList<>();
	listObj.add("Steve");
	listObj.add("Mark");
	listObj.add("Bill");
	listObj.remove("Bill");
	listObj.isEmpty();
	boolean ifPresent=listObj.contains("Bill");
	if(ifPresent)
	{
		System.out.println("Congrats String Bill Found");
	}
	else
	{
		System.out.println("No String named Bill found");
	}
	listObj.get(2);
iterateAndPrint(listObj);
	System.out.println();
	System.out.println("Ater adding the duplicates");
	listObj.add("A");
	iterateAndPrint(listObj);
	System.out.println("Ater adding the null");
	listObj.add(null);
	iterateAndPrint(listObj);

}

	private static void iterateAndPrint(List<String> listObj) {
		Iterator<String> iteratorObj=listObj.iterator();
		while(iteratorObj.hasNext())
		{
			System.out.println(""+iteratorObj.next());
		}
	}
}
