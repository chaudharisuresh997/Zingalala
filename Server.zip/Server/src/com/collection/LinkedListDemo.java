package com.collection;

import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListDemo {
public static void main(String[] args) {
	LinkedList<String> linkedObj=new LinkedList<>();
	linkedObj.add("Bill");
	linkedObj.add("Steve");
	linkedObj.add("Smith");
	linkedObj.add("Emi");
	linkedObj.add("Sunny");
	linkedObj.addLast("Mark");
	linkedObj.addFirst("Elon");
	
	linkedObj.removeFirst();//removes the first element from the linked list
	linkedObj.remove();//removes the element that lies at the head of list
	linkedObj.poll();//gives you the first element but removes the element from the list
	linkedObj.pop();//just like removeFirst
	linkedObj.isEmpty();//to check if list contains at least one item
	linkedObj.peek();//gives you the first element but it does not remove
	
	
	ListIterator<String> list=linkedObj.listIterator();
	while(list.hasNext())
	{
		System.out.println(""+list.next());
	}
	//ListIterator<String> list1=linkedObj.listIterator();
	System.out.println("Now just print in reverse order");
	while(list.hasPrevious())
	{
		System.out.println(""+list.previous());
	}
	
}
}
