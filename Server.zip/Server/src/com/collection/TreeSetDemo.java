package com.collection;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		Set<String> setObj=new TreeSet<>();
		setObj.add("zone");
		setObj.add("zoo");
		setObj.add("bajuka");
		setObj.add("jzoo");
		setObj.add("azoo");
		setObj.remove("zone");
	//	setObj.add(null); while iterating gives nullpointer exception
		
		iterateAndPrint(setObj);
		

	}
	public static void iterateAndPrint(Set treeMapObj)
	{
		
	Iterator<String> it=treeMapObj.iterator();
			
		while(it.hasNext())
		{
			System.out.println("Value=>"+it.next());
		}
	}

}
/**
 * Value=>azoo
Value=>bajuka
Value=>jzoo
Value=>zoo

 * 
 */

