package com.collection;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

public class IdentityHashMapDemo {

	public static void main(String[] args) {
	Map<String,String> maps=new IdentityHashMap<>();
	
	maps.put("1", "one");
	maps.put("2", "two");
	iterateAndPrint(maps);
	System.out.println();
System.out.println("After adding null key and value as two");	
	maps.put(null, "two");
	iterateAndPrint(maps);
	System.out.println();
	System.out.println("After adding null key and value as three");
	
	maps.put(null, "three");
	iterateAndPrint(maps);
	}
	public static void iterateAndPrint(Map treeMapObj)
	{
		Set<String> keySet=treeMapObj.keySet();
	
		for(String oneKey:keySet)
		{
			System.out.println("key=>"+oneKey+" Value is=>"+treeMapObj.get(oneKey));
		}
	}
}
/**
 * Output
 * key=>1 Value is=>one
key=>2 Value is=>two

After adding null key and value as two
key=>1 Value is=>one
key=>null Value is=>two
key=>2 Value is=>two

After adding null key and value as three
key=>1 Value is=>one
key=>null Value is=>three
key=>2 Value is=>two

 * 
 * 
 */
