package com.collection;

import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class SortedSetDemo {

	public static void main(String[] args) {
		SortedSet<String> linkedHashSet=new TreeSet<>();
		linkedHashSet.add("zak");
		linkedHashSet.add("ak");
		linkedHashSet.add("k");
		
		linkedHashSet.add("k");
		linkedHashSet.add("k");
		System.out.println("Output After Adding duplicates");
		iterateAndPrint(linkedHashSet);//repeated elements will be removed.
		//order of elements is preserved.
		
		System.out.println("Output after adding null");
		linkedHashSet.add(null);//check if null is entertained.
		iterateAndPrint(linkedHashSet);//NUll Not ALLOWED
		
	}
	public static void iterateAndPrint(SortedSet linkedHashSet)
	{
		
	Iterator<String> it=linkedHashSet.iterator();
			
		while(it.hasNext())
		{
			System.out.println("Value=>"+it.next());
		}
	}

}
/**
 * 		Output
 * 		Output After Adding duplicates
			
			Value=>zak
			Value=>ak
			Value=>k
		
		Output after adding null
			
			Value=>zak
			Value=>ak
			Value=>k
			Value=>null

 * 
 */

