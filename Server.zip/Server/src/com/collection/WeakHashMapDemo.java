package com.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
/**Rules:1.Null value as well as Null Key are permitted here.
 * 2.	 used for cache also for lookup storage.
 * 3.Entries if not used anywhere they can be removed at the same time this makes 
 * WeakHashMap efficient for garbage collection.
 * 
 * 
 * 
 *
 */
public class WeakHashMapDemo {
	public static void main(String[] args) 
	{
		WeakHashMap<String, String> weakObj=new WeakHashMap<String,String>();
		weakObj.put("1", "One");
		weakObj.put("2", "Two");
		for(int i=3;i<10;i++)
		{
			weakObj.put(""+i, "Two");	
		}
		iterateAndPrint(weakObj);
		System.out.println("Value of Key 1 is "+weakObj.get(1));//If refernce not needed anymopre entry removed so 
		//output is null
		
	}
	public static void iterateAndPrint(Map treeMapObj)
	{
		@SuppressWarnings("unchecked")
		Set<String> keySet=treeMapObj.keySet();
	
		for(String oneKey:keySet)
		{
			System.out.println("key=>"+oneKey+" Value is=>"+treeMapObj.get(oneKey));
		}
	
	}
}
/**
 * OUtput
 *key=>8 Value is=>Two
key=>9 Value is=>Two
key=>4 Value is=>Two
key=>5 Value is=>Two
key=>6 Value is=>Two
key=>7 Value is=>Two
key=>1 Value is=>One
key=>2 Value is=>Two
key=>3 Value is=>Two
Value of Key 1 is null


 * 
 * 
 */
