/**
 * 
 */
/**
 * @author 601840
 *
 */
package com.collection;
/**
 * 	Collection
 * 		Set
 * 			HashSet--DONE
 * 					LinkedHashSet-Done
 * 
 * 			TreeSet--DONE
 * 			SortedSet--DONE
 * 
 * 		List
 * 			ArrayList  DONE
 * 			Vector     DONE
 * 		Queue
 * 		
 * 	Map
 * 		SortedMap
 * 					TreeMap--DONE
 * 		HashMap--DONE
 * 					LinkedHashMap
 * 		IdentityHashMap-DONE  
 * 		WeakHashMap--DONE
 * 
 * 			
 * 
 * 
 */



