package com.collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> listObj=new Vector<>();
		listObj.add("Z");
		listObj.add("J");
		listObj.add("A");
		
	iterateAndPrint(listObj);
		System.out.println();
		System.out.println("Ater adding the duplicates");
		listObj.add("A");
		iterateAndPrint(listObj);
		System.out.println("Ater adding the null");
		listObj.add(null);
		iterateAndPrint(listObj);

	}
	private static void iterateAndPrint(List<String> listObj) {
		Iterator<String> iteratorObj=listObj.iterator();
		while(iteratorObj.hasNext())
		{
			System.out.println(""+iteratorObj.next());
		}
	}

}
/**  Output
 * 	Z
	J
	A

		After adding the duplicates
	Z
	J
	A
	A
		Ater adding the null
	Z
	J
	A
	A
	null

 */
