package com.collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
/**
 * 
 * 
 * 
 *Rules:	1.Hashset can have null 
 *			2.HashSet can have only unique items.
 *			3.Internally hashset implemented using hashmap and every item stored in 
 *			HashSet is stored as key in HashMap and dummy Object is added as value in hashmap
 *			In this way hashset maintains uniquenes. 
 *			HashSet does not maintain order
 *			
 */			
public class HashSetExample {

	public static void main(String[] args) {
		Set<String> hashSetObj=new HashSet<String>();
		hashSetObj.add("Shiv");hashSetObj.add("Shiv");
		hashSetObj.add(null);hashSetObj.add("jagjit");
		hashSetObj.add("amar");
		
		Iterator<String> it=hashSetObj.iterator();
		while(it.hasNext())
		{
			System.out.println(""+it.next());
		}

	}

}
/*
 * Output
null
amar
Shiv
jagjit
*/

