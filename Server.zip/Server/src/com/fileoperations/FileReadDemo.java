package com.fileoperations;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
class ReadMyFile
{
	public void readFile()
	{
	

	FileReader fis; 
	BufferedReader readBuffer;
	try{
		fis=new FileReader("C:\\Users\\601840\\Documents\\data-access-context.xml");
		readBuffer=new BufferedReader(fis);
		String line;
		while((line=readBuffer.readLine())!=null)
		{
			System.out.println(""+line);
		}
	
	}catch(Exception ex)
	{
		System.out.println(""+ex.getMessage());
	}
	}

}
public class FileReadDemo {
	public static void main(String[] args) {
		ReadMyFile readObj=new ReadMyFile();
		readObj.readFile();
	}
}
