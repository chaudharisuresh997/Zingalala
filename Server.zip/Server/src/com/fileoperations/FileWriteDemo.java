package com.fileoperations;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

class WriteMyFile
{
	public void writeFile()
	{
		FileWriter fileWriteObj=null;
		BufferedWriter bufferedWriter=null;
		try {
			fileWriteObj=new FileWriter("D:\\test.txt");
			bufferedWriter=new BufferedWriter(fileWriteObj);
			bufferedWriter.write("Thank you reader for accpeting my book :)");
			
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				bufferedWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				fileWriteObj.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
}
public class FileWriteDemo {
public static void main(String[] args) {
	WriteMyFile wrietObj=new WriteMyFile();
	wrietObj.writeFile();
	
}
}
