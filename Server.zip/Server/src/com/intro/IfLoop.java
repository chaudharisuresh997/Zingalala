package com.intro;

public class IfLoop {

	public static void main(String[] args) {
	int var1=5;
	int var2=7;
	
	
	/********If Else Demo*****/
	if(var1<var2)
	{
		System.out.println("var1 is less than var2");
	}
	else if(var1>var2)
	{
		
		System.out.println("var1 is Greater than var2");
	}
	else
	{
		System.out.println("Var1 equal to var2");
		
	}

	}

}
