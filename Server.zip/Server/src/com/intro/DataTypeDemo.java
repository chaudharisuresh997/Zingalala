package com.intro;

public class DataTypeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int intVar=2;
		System.out.println(""+intVar);
		
		double doubleVar=2;
		System.out.println(""+intVar);
		
		float floatVar=2.5f;
		System.out.println(""+floatVar);
		
		char charVar='c';
		System.out.println(""+charVar);
		
		boolean isPassed=true;
		
		System.out.println("Is passed"+isPassed);
	}
	

}
