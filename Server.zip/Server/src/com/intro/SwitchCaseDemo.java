package com.intro;

public class SwitchCaseDemo {
	public static void main(String[] args) {
		int no=1;
		switch(no)
		{
			case 1:	System.out.println("no is 1");
			break;
			case 2:	System.out.println("no is 2");
			break;
			default:	System.out.println("When every case fails default case gets executed.");
			break;
		}	
	}
	
}
