package com.designpatterb;
interface Shower{//This is target interface
	public void sprinkleWater();
	
	
}
class Tap implements Shower{
	public void runningWater()
	{
		System.out.println("Running Water");
		
	}

	@Override
	public void sprinkleWater() {
		System.out.println("Running Water");
		
	}
	
}
public class AdapterPattern {

	public static void main(String[] args) {
		Shower showerObj=new Tap();
		showerObj.sprinkleWater();

	}

}
