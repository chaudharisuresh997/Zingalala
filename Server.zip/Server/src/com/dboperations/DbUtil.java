package com.dboperations;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

import java.sql.*;  
class GetRecordsFromDb{  
	public static void main(String args[]){  
		try{  
			//This class communicates with java and the oracle database 
			Class.forName("oracle.jdbc.driver.OracleDriver");  

			//public static Connection getConnection(String url,
			//String user, String password) throws SQLException
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");  


			Statement stmt=con.createStatement();  

			//Don't you worry resultset is just another bucket which has all employee records 
			ResultSet rs=stmt.executeQuery("select * from emp");
			int result=stmt.executeUpdate("insert into emp values('userName','passWord')");
			while(rs.next())
			{
				//now we got the one record of employee.
				System.out.println(rs.getString("name")+"  "+rs.getString("empId"));  

			}		
			con.close();  

		}catch(Exception exceptionObj){ 
			System.out.println("sorry error in connection"+exceptionObj.getMessage());
		}  

	}  
}  

public class DbUtil {
	public void ABC(){
	}
	public static void main(String[] args) {


	}

}
