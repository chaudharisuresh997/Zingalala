package com.oop;
abstract class BookCab
{
	public abstract void reserveCab();
	public void cancelCab()
	{
		System.out.println("Cab Got Cancelled");
	}
}
class BookCabImpl extends BookCab
{
	@Override
	public void reserveCab() {
	
		System.out.println("Implenting Abstract Method of BookCab");
		
	}
}
public class AbstractClassDemo {

	public static void main(String[] args) {
		/*BookCab bookcAb=new Bookcab(); 
			We can not create instance of the abstract class
		*/
		BookCabImpl bImpl=new BookCabImpl();
		bImpl.reserveCab();
		bImpl.cancelCab();
	
	}

}
//RULES
/**
 * 1.	Abstract class can implement interfaces
 * 2.	Abstract class methods must be implemented as the abstract
 * 3.	The class should extend Abstract class and implement all the abstract methods.
 * 4.	Abstract class can not create instance directly.
 * 5.	It is illegal to define abstract methods as final.
 * 6.	We Can not define abstract as FINAL.
 * 7.	Abstract method can not be declared as STATIC.
 * 8.	Any method if declared abstract has to be implemented by the class which extends the abstract class
 * 		Failed to define the method implementation the extended class should be declared as abstract.
 */


