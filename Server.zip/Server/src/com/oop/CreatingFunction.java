package com.oop;

public class CreatingFunction {
	public static void printMe()
	{
		System.out.println("Hi Method Called");
	}
	
	public static void main(String[] args) {
		
		printMe();
	}

}
