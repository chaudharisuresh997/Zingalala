package com.oop;
class Account
{
	int balance=0;
	Account()
	{
		this("Hows u");
		System.out.println("My intial balance is "+balance);
	}
	Account(int balance)
	{
		this();//This calls its default constructor
		this.balance=balance;
				System.out.println("My Updated Balance is"+this.balance);
	}
	
	Account(String msg)
	{
		System.out.println("I am called by this(msg)"+msg);
	}

}
public class ConstructorChainingDemo {

	public static void main(String[] args) {
		Account accountObj=new Account(23);
		
		/*Sequence Of execution */
		/**
		 * 1.Account(String msg)
		 * 2.Account()
		 * 3.Account(int balance)
		 * 
		 * OutPut
		 * _________________
		 * I am called by this(msg)Hows u
			My intial balance is 0
			My Updated Balance is23
		 * 
		 */
		

	}

}
