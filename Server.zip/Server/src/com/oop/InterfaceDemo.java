package com.oop;
interface School
{
	public int foundedYear=1986;
	/*SchoolFunctions()
	{
	Interface does not have aconstructo	
	}*/
	
	public void admitStudent();
	//method admitStudent can not have it's implementation
	public void teachStudents();
	public void carryExams();
	
}
class StudentFunctionImpl implements School
{
	//RULE: all variables in interface are public static final
		/**This means we can't change value of foundedYear
		 * 
		 */
	@Override
	public void admitStudent() {
		
	System.out.println("implementation of admitStudent");
	}

	@Override
	public void teachStudents() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void carryExams() {
		// TODO Auto-generated method stub		
	}	
}
public class InterfaceDemo {

	public static void main(String[] args) {
		//Studentfunctions s=new Studentfunctions();
		//RULE:We can't create object of interface
		 
		StudentFunctionImpl studObj=new StudentFunctionImpl();
		//However interface reference can point to instance of implemented class
		School studF=new StudentFunctionImpl();
		studF.admitStudent();

	}

}
