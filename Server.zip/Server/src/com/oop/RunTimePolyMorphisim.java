package com.oop;
class Car{
	
	public void drive()
	{
		System.out.println("in Car");
	}
}
class SuperCar extends Car
{

	public void drive()//We Can not make drive as protected or private Rule of overriding
		{
		System.out.println("in SuperCar");
	}
	public void musicPlayer()
	{
		
	}
}
public class RunTimePolyMorphisim 
{

	public static void main(String[] args) 
	{	
	Car superObj=new SuperCar();
	//superObj.musicPlayer();//error:The method musicPlayer() is undefined for the type Car
	/**Above Line gives compile time error as
	 * Car(superclass) reference holds instance of SuperCar(which is subclass)
	 * so superObj.musicPlayer(); and no method named musicPlayer defined in the super class
	 *  
	 */
	superObj.drive();
	/***Case 2:TypeCast and see**/
	Car superObjCast=(Car)new SuperCar();
	superObjCast.drive();
	//OutPUT :::	System.out.println("in SuperCar");
	
	SuperCar reverseObj=(SuperCar)new Car();
	superObjCast.drive();
	/**Above line gives 
	 * Exception in thread "main" java.lang.ClassCastException: com.oop.Car cannot be cast to com.oop.SuperCar
	at com.oop.RunTimePolyMorphisim.main(RunTimePolyMorphisim.java:39)
	 */
	}

}
