package com.oop;
class PersonWithGetterSetter
{
	private String name;	
	private int salary;
	
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public void printPerson(PersonWithGetterSetter p)
	{
		System.out.println("Person's Name: "+p.name);
		//here it can be accessed as
		//private variable are accessible in same class
		System.out.println("Person's salary: "+p.salary);
	}
	
}


public class UserClassEncapsulation {

public static void main(String[] args) {
		
	PersonWithGetterSetter p=new PersonWithGetterSetter();
			/*This will create error as private variable can not be used directly
			 * p.salary=2000;
			p.name="Suresh";
			so this is accessed using public methods of class Person 
			*/
			p.setName("Suresh");
			p.setSalary(25000);
		
			p.printPerson(p);		
			

	}

}

