package com.oop;
class Person
{
	int salary;
	String name;
	
	public void printPerson(Person p)
	{
		System.out.println("Person's Name: "+p.name);
		System.out.println("Person's salary: "+p.salary);
	}


	
}
public class UserClassDemo {

	public static void main(String[] args) {
		
		Person p=new Person();
			p.salary=2000;
			p.name="Suresh";
			
			p.printPerson(p);		
			

	}

}
