package com.oop;
class Parent
{
	Parent()
	{
		System.out.println("parent called");
	}

}
class Child extends Parent
{
	Child()
	{
	System.out.println("Child called");
	}
}
public class ConstructorProperties {

	public static void main(String[] args) {
	
		Child childObj=new Child();
		//Constructor First calls the parent constructor 
		//then it calls the child constructor
		
	}

}
/*---------Output ------------------
 *parent called
 Child called 
 * 
 */ 
