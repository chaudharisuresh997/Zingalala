package com.oop;
class Calc
{
	public void addMe(int no1,int no2)
	{
		System.out.println("Addtion of integer is"+(no1+no2));
	}
	public void addMe(float no1,float no2)
	{
		System.out.println("Addtion of float is "+(no1+no2));
	}

}
public class Polymorphism {

	public static void main(String[] args) {
		
		Calc c=new Calc();
		c.addMe(2.3f, 4.5f);
		//AS both parameters are float it calls method 
		//which takes argument as float 
		
		c.addMe(2, 3);
		//AS both parameters are integer it calls method 
				//which takes argument as integer
	}

}
