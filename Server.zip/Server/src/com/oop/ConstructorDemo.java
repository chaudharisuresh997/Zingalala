package com.oop;
class Phone
{
	String name;
	float size;
		public Phone()
	{
		System.out.println("Default Constructor Called");
	}
	public Phone(String name, float salary) {
		super();
		this.name = name;
		this.size = salary;
		System.out.println("Parameterized Called");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public float getSize() {
		return size;
	}
	public void setSize(float size) {
		this.size = size;
	}

}
public class ConstructorDemo {

	public static void main(String[] args) {
		//nOW BENEFIT OF CONSTRUCTOR YOU CAN 
		//INITIALIZE CONSTUCTOR ON SAME LINE and load object with all default values also
		Phone pObj=new Phone("Xiomi", 5.5f);
		
		Phone pObj1=new Phone("Xiomi", 5.5f);
		
		Phone pObj2=new Phone("Xiomi", 5.5f);	

	}

}
