package com.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class Student1 implements Serializable
{
	transient private String studentName;
	private int	rollNo;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}


}
public class checkTransient {

	public static void main(String[] args) {
		serializeMyObject();
		deserializeMyObject();

	}

	private static void deserializeMyObject() {
		ObjectInputStream objectInputStream = null;
		Student1 studObj=null;
		try {
			objectInputStream = new ObjectInputStream(new FileInputStream(new File("emp.txt")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			studObj=(Student1)objectInputStream.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objectInputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Deserialized Objects Values");
		System.out.println("RollNo : "+studObj.getRollNo());
		System.out.println("Name : "+studObj.getStudentName());
	}

	private static void serializeMyObject() {
		ObjectOutputStream objOut=null;
		try {
			objOut=new ObjectOutputStream(new FileOutputStream(new File("emp.txt")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Student1 studObj=new Student1();
		studObj.setStudentName("Shiv");
		studObj.setRollNo(1);
		
		try {
			objOut.writeObject(studObj);
			objOut.flush();
			objOut.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
