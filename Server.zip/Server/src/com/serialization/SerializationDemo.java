package com.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class Student implements Serializable
{
	private String studentName;
	private int	rollNo;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}


}
public class SerializationDemo {

	public static void main(String[] args) {
		serializeMyObject();
		deserializeMyObject();

	}

	private static void deserializeMyObject() {
		ObjectInputStream objectInputStream = null;
		Student studObj=null;
		try {
			objectInputStream = new ObjectInputStream(new FileInputStream(new File("emp.txt")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			studObj=(Student)objectInputStream.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Deserialized Objects Values");
		System.out.println("RollNo : "+studObj.getRollNo());
		System.out.println("Name : "+studObj.getStudentName());
	}

	private static void serializeMyObject() {
		ObjectOutputStream objOut=null;
		File file=new File("emp.txt");
		FileOutputStream fos;
		try {
			fos=new FileOutputStream(file);
			
			objOut=new ObjectOutputStream(fos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Student studObj=new Student();
		studObj.setStudentName("Shiv");
		studObj.setRollNo(1);
		
		try {
			objOut.writeObject(studObj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
