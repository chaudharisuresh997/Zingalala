package com.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class Person implements Serializable
{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static int age=23;
	private String studentName;
	private int	rollNo;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}


}
public class RulesSerializationDemo {

	public static void main(String[] args) {
		Person studObj=new Person();
		studObj.setStudentName("Shiv");
		studObj.setRollNo(1);
		serializeMyObject(studObj);
	
		
		deserializeMyObject();

	}

	private static void deserializeMyObject() {

		ObjectInputStream objectInputStream = null;
		Person studObj=null;
		try {
			objectInputStream = new ObjectInputStream(new FileInputStream(new File("emp.txt")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			studObj=(Person)objectInputStream.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Deserialized Objects Values address wont appear as it is static ");
		System.out.println("RollNo : "+studObj.getRollNo());
		System.out.println("Name : "+studObj.getStudentName());
		System.out.println("Age : "+Person.age);
		
		
		
		System.out.println("Aftre modifyingAddress : "+Person.age);
	}

	private static void serializeMyObject(Person studObj) {
		ObjectOutputStream objOut=null;
		try {
			objOut=new ObjectOutputStream(new FileOutputStream(new File("emp.txt")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		try {
			objOut.writeObject(studObj);
			Person.age=9055;//This line will give compile time error.
			studObj.setStudentName("SHivaji");
			objOut.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
