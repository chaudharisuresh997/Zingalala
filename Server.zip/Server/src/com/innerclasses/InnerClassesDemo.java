package com.innerclasses;
/**
 * Why inner classes came in picture.
 * Consider the scenario where you need to protect the piece of code 
 * from the rest of the classes except ONE class(in our case class A)
 * 
 * So the main purpose is protection of code.
 * Restrict access for that code.Only one class can access it 
 * Other class can not see it.To see the class means they can not create the object of such class (i.e class B)
 *	and access the methods within the class.
 */
class A{
	
	
	class B
	{
		public void print()
		{
			
			System.out.println("I am protected");
		}
		
	}
	public void accessB()
	{
		B bObj=new B();
		bObj.print();
		
	}
}
public class InnerClassesDemo {

	public static void main(String[] args) {
		A aObj=new A();
		aObj.accessB();

	}

}
