package com.innerclasses;
/*
 * As the name suggests the class is static and nested inside another class
 * Steps are
 * Declare a class
 * 		Declare a static class inside the previously create class
 * 		Define method inside the static class 
 * End class
 * 
 * How to access them
 * 		As you know the static method can be access by using ClassName.method();
 * 		Same way static class will be accessed 
 */
public class StaticNestedClass {
	static class Inner{
		public void innerMethod()
		{
			System.out.println("I am static class's inner method");
		}
		
	} 
public static void main(String[] args) {
	StaticNestedClass.Inner innerObj=new StaticNestedClass.Inner();
	innerObj.innerMethod();
}
}
