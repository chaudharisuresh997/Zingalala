package com.innerclasses;
//Anon Innerclasss comes handy when you just need to override the small piece of
//code.
//Instead creating a seprate class for just single method is not cool :)
//So quicker way is go for the annonymous inner class.


abstract class ListenEvent
{
	public abstract void deleteEvent();
	
}
public class AnnonInnerDemo {

	public static void main(String[] args) {
		ListenEvent listen=new ListenEvent() {
			
			@Override
			public void deleteEvent() {
			
			System.out.println("I have defined annonnymous inner class");	
			}
		};

	}

}
