package com.innerclasses;
/**
 * Class is called method local inner class is because 
 * We keep the class inside the method.
 * 
 * 
 * 
 * 
 *
 */
public class MethodLocalInnerClass {

	public void print()
	{
		class Inner{
			public void innerMethod()
			{
				System.out.println("The inner class demo");
			}
			
		}
		Inner innerObj=new Inner();
		innerObj.innerMethod();
	}
	public static void main(String[] args) {
		MethodLocalInnerClass obj=new MethodLocalInnerClass();
		obj.print();
	}
}
