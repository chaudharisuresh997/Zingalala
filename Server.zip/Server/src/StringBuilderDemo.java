
public class StringBuilderDemo {

public static void main(String[] args) {
	StringBuilder strBuilder=new StringBuilder();
	strBuilder.append("First");
	strBuilder.append("Second");
	
	System.out.println("Length of String==>"+strBuilder.length());
	System.out.println("Length of String==>"+strBuilder.indexOf("Second"));
	StringBuilder newString=strBuilder.replace(0, 5, "replaced ");
	System.out.println(newString);
	
	//Rest of the functions are same a in StringBuffer.
}
}
/*
Length of String==>11
Length of String==>5
replaced Second
*/