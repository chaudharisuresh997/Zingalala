</div> <!-- MAINAREA -->



<div id="footer">

	<div class="left">
		Copyright (c) 2008 <?php bloginfo('name'); ?><br/>
	</div>
	<div class="right">
		Using the <a href="http://www.dailyblogtips.com/wordpress-themes/">Darkzen Theme</a><br/>
	</div>
</div>
</div> <!-- PAGE -->
</div>

		<?php do_action('wp_footer'); ?>

</body>
</html>
