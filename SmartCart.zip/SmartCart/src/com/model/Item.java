package com.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


//@XmlAccessorType (XmlAccessType.NONE)
@XmlRootElement(name="ShoppingCart")
public class Item {
	
	//@XmlElement(name="itemID")
	private Integer itemID;
	//@XmlElement(name="itemCategoryID")
	private Integer itemCategoryID;
	//@XmlElement(name="itemName")
	private String itemName;
	//@XmlElement(name="unitPrice")
	private double unitPrice;
	//@XmlElement(name="quantity")
	Integer quantity;
	public Integer getItemID() {
		return itemID;
	}
	public void setItemID(Integer itemID) {
		this.itemID = itemID;
	}
	public Integer getItemCategoryID() {
		return itemCategoryID;
	}
	public void setItemCategoryID(Integer itemCategoryID) {
		this.itemCategoryID = itemCategoryID;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
}
