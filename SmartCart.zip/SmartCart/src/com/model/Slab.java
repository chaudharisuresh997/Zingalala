package com.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Slab")
@XmlAccessorType (XmlAccessType.FIELD)
public class Slab {
	private Integer RangeMin;
	 private Integer RangeMax;
	 private Integer discPerc;
	public Integer getRangeMin() {
		return RangeMin;
	}
	public void setRangeMin(Integer rangeMin) {
		RangeMin = rangeMin;
	}
	public Integer getRangeMax() {
		return RangeMax;
	}
	public void setRangeMax(Integer rangeMax) {
		RangeMax = rangeMax;
	}
	public Integer getDiscPerc() {
		return discPerc;
	}
	public void setDiscPerc(Integer discPerc) {
		this.discPerc = discPerc;
	}
}
