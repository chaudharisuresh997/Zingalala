package com.bo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.Categories;
import com.model.Category;
import com.model.Discounts;
import com.model.Item;
import com.model.Slab;

public class ProcessDiscount {
	double netTotal=0;
	StringBuilder finalInVoice=new StringBuilder();
	Map<String,Category> categoryMap=new HashMap<String,Category>();

	public void inItCategoryMap(Categories categories)
	{
		List<Category> cats=categories.getCategories();
		for(Category catObj:cats)
		{
			categoryMap.put(catObj.getId().toString(), catObj);	
		}
	}


	public void processBill(Categories categories,Discounts discounts,List<Item> itemsInCart)
	{
		inItCategoryMap(categories);
		double unitsCatTotalPrice;
		for(Item item:itemsInCart)
		{	
			String catId=item.getItemCategoryID();
			double totalForUnit=item.getQuantity()*item.getUnitPrice();
			int disCountForCategory=categoryMap.get(""+Integer.parseInt(catId)).getDiscPerc();		


			//one category item price after applying discount.
			unitsCatTotalPrice=calculateDiscounts(disCountForCategory,totalForUnit);
			finalInVoice.append("\n"+item.getItemName()+": "+item.getQuantity()+":"+item.getUnitPrice()+":"+disCountForCategory+":"+unitsCatTotalPrice);
			netTotal=netTotal+unitsCatTotalPrice;


		}
		finalInVoice.append("\n"+"NET TOTAL"+netTotal);

		//slab wise apply discount to net total.
		finalInVoice.append("\n"+"GrAND TOTAL"+calculateFinalGrandTotal(netTotal,discounts)+"Applicable DisCount"+discounts+"Net Bill Amount(without slab)"+netTotal);
		generateInvoice(finalInVoice);
	}

	private void generateInvoice(StringBuilder finalInVoice) {
		System.out.println(finalInVoice.toString());

	}

	private double calculateFinalGrandTotal(double netTotal,Discounts discounts) {
		List<Slab> slabs=discounts.getSlab();
		double grandTotal=0.0;
		for(Slab slab:slabs)
		{
			if(notZero(slab.getDiscPerc()))
			{
				if((notZero(slab.getRangeMax())))
				{
					if((netTotal<slab.getRangeMax()) &&(netTotal>slab.getRangeMin()))
					{
						grandTotal=calculateDiscounts(slab.getDiscPerc(),netTotal);
					}

				}
				else if((netTotal>slab.getRangeMin())&&(slab.getRangeMax()==0))
				{
					
					grandTotal=calculateDiscounts(slab.getDiscPerc(),netTotal);
				}
			}
			else
			{
				grandTotal=netTotal;
			}

		}
		return grandTotal;

	}

	public double calculateDiscounts(int disCountForCategory,double totalForUnit)
	{
		double discount=100-disCountForCategory;
		return discount*(totalForUnit/100);

	}
	private boolean notZero(double disCountPerc){
		boolean isZero=true;
		if(disCountPerc==0.0)
		{
			isZero=false;
		}
		else
		{
			isZero=true;
		}
		return isZero;
	}
}
