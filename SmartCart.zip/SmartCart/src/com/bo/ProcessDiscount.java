package com.bo;

import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import com.model.Categories;
import com.model.Category;

public class ProcessDiscount {
	
public List<Category> categories;

public List<Category> getCategories() {
	return categories;
}

public void setCategories(List<Category> categories) {
	this.categories = categories;
}
	

}
