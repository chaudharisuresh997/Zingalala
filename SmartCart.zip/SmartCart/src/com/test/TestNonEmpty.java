package com.test;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Test;

import com.bo.ProcessDiscount;
import com.model.Carts;
import com.model.Categories;
import com.model.Discounts;
import com.model.Item;
import com.util.ProcessXML;

public class TestNonEmpty {
	List<Item> items=null;
	Categories categories = null;
	Discounts discounts=null;
	@SuppressWarnings("deprecation")
	@Test
	public void checkNonEmptyCategory(){
		
		
		//Read category XML and make List out of it 
		try {
			categories=(Categories)new ProcessXML().giveJaxB(Categories.class,"category.xml");
		} catch (JAXBException e2) {			
			e2.printStackTrace();
		}
		Assert.assertNotNull("Categories not null",categories);
	}
	@Test
	public void checkNonEmptyDiscounts()
	{
		
		try {
			discounts=(Discounts)new ProcessXML().giveJaxB(Discounts.class,"discounts.xml");
		} catch (JAXBException e1) {
			e1.printStackTrace();
		}
		Assert.assertNotNull("Discounts not null",discounts);
	}
	@Test
	public void checkShoppingCart()
	{
		
		//Read shopping cart xml
				try {

					items=new ProcessXML().createShoppingCart();

				} catch (NumberFormatException e) {
					e.printStackTrace();

				} catch (IOException e) {
					e.printStackTrace();

				}
				Assert.assertNotNull("Shopping cart not null",items);		
	}
	

}
