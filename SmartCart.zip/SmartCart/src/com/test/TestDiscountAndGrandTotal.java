package com.test;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import com.bo.ProcessDiscount;
import com.model.Categories;
import com.model.Discounts;
import com.model.Item;
import com.util.ProcessXML;

/**
 * 
 * @author suresh
 *
 */

public class TestDiscountAndGrandTotal {
	public static void main(String[] args){
		Categories categories=null;
		Discounts discounts=null;
		List<Item> items=null;
		//Read category XML and make List out of it 
		try {
			categories=(Categories)new ProcessXML().giveJaxB(Categories.class,"category.xml");
		} catch (JAXBException e2) {			
			e2.printStackTrace();
		}

		//Read discounts XML and make List out of it
		try {
			discounts=(Discounts)new ProcessXML().giveJaxB(Discounts.class,"discounts.xml");
		} catch (JAXBException e1) {
			e1.printStackTrace();
		}
		//Read shopping cart xml
		try {

			items=new ProcessXML().createShoppingCart();

		} catch (NumberFormatException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();

		}


new ProcessDiscount().processBill(categories, discounts, items);
	}




}






