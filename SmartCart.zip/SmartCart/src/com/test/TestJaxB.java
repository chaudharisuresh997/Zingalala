package com.test;
import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.model.Carts;
import com.model.Item;
class ReadFile{
	JAXBContext jaxbContext;
	public File read(String fileName)
	{
	 	 ClassLoader classLoader = getClass().getClassLoader();
 		File file = new File(classLoader.getResource(fileName).getFile());

		return file;
	}
	public Object giveJaxB(Class classObj,String fileName) throws JAXBException
	{
		File fileObj=read(fileName);
		try {
			jaxbContext = JAXBContext.newInstance(classObj);
		
		} catch (JAXBException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}  
		JAXBContext jaxbContext = JAXBContext.newInstance(Carts.class);    
	    
	    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();    
	    Object object=(Object) jaxbUnmarshaller.unmarshal(fileObj); 
	   
	   return object; 
	    
				
	}
	
}
public class TestJaxB {
	

	public static void main(String[] args) throws JAXBException {
	  
		  /*Categories categories=(Categories)new ReadFile().giveJaxB(Categories.class,"category.xml");
		  
		  Discounts discounts=(Discounts)new ReadFile().giveJaxB(Discounts.class,"discounts.xml");*/

		Carts item=(Carts)new ReadFile().giveJaxB(Item.class,"shoppingcart.xml");
		            
		              
		            
		         
		}  
		


	}


