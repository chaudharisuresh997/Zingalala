package com.util;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import com.model.Categories;
class ReadFile{
	public File readXML(String xml)
	{
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(xml).getFile());

		return file;
	}
}
	public class Process {
		JAXBContext jaxbContext;
		
		
	}

