package com.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.model.Item;

public class ProcessXML{

	List<Item> itemsInCart=null;
	

	int first;

	int last;

	JAXBContext jaxbContext;

	public File read(String fileName)

	{

		ClassLoader classLoader = getClass().getClassLoader();

		File file = new File(classLoader.getResource(fileName).getFile());

		if(file==null)
		{
			
				try {
					throw new FileNotFoundException("File not Found");
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		return file;

	}

	public Object giveJaxB(Class classObj,String fileName) throws JAXBException

	{

		File fileObj=read(fileName);

		try {

			jaxbContext = JAXBContext.newInstance(classObj);


		} catch (JAXBException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		


		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

		Object object=(Object) jaxbUnmarshaller.unmarshal(fileObj);


		return notNull(object);



	}

	public List<Item> createShoppingCart() throws NumberFormatException, IOException

	{
		itemsInCart=new ArrayList<Item>();
		Scanner sc=null;

		File fileObj=read("shoppingcart.xml");

		try {

			sc=new Scanner(fileObj);

		} catch (FileNotFoundException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		Item item=null;

		BufferedReader br=null;

		try {

			br=new BufferedReader(new FileReader(fileObj));

		} catch (FileNotFoundException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		String line;

		while((line=br.readLine())!=null)

		{
			if(line.contains(Constants.itemID))

			{item=new Item();
				

			notNull(item).setItemID(parseString(line));

			}
			else if(line.contains(Constants.itemCategoryID))
			{		

			notNull(item).setItemCategoryID(parseString(line));

			}
			else if(line.contains(Constants.itemName))
			{

			notNull(item).setItemName(parseString(line));

			}

			else if(line.contains(Constants.quantity))
			{

			notNull(item).setQuantity(Integer.parseInt(parseString(line)));

			}
			else if(line.contains(Constants.unitPrice))
			{
				notNull(item).setUnitPrice(Double.parseDouble(parseString(line)));

				itemsInCart.add(item);
			}



		}
		return itemsInCart;
		
	}

	public String parseString(String inputXmlString)

	{

		first=inputXmlString.indexOf(">"); last=inputXmlString.lastIndexOf("</");

		return inputXmlString.substring(first+1, last);



	}
	public Object notNull(Object object)
	{
		
		if(object==null)
		{
			try{
			throw new NullPointerException();
			}catch(NullPointerException npException)
			{
				System.out.println("Null Object");
			}
		}
		return object;
		
	}
	public Item notNull(Item item)

	{

		if(item==null){

			return new Item();

		}else{

			return item;

		}

	}
	/*public static void main(String[] args) {
		try {
			new ProcessXML().giveJaxB(Categories.class, "category.xml");
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/

}