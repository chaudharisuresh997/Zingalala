package com.util;

public class Constants {

public static String itemID="itemID";

public static String itemCategoryID="itemCategoryID";

public static String itemName="itemName";

public static String unitPrice="unitPrice";

public static String quantity="quantity";


}


