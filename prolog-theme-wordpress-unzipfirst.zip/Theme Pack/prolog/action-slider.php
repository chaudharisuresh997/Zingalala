
<div id="action-slider">
		<div class="row">
			<div class="col-md-4">
				<div class="prolog-action">
					<h2>Hey There !</h2>
					<p>Welcome to our new theme Prolog</p>
					<a class="btn-action" href="#">Try It Now</a>  <i class="fa fa-long-arrow-right"></i>
				</div>

			</div>

			<div class="col-md-8">
	            <div id="carousel-container">
	                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
	                    <ol class="carousel-indicators">
	                        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
	                        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
	                        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
	                    </ol>
	                    <div class="carousel-inner">
	                        <div class="item active">
	                            <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/images/my-profile-bg.jpg">
	                            <div class="carousel-caption">
	                            </div>
	                        </div>
	                        <div class="item">
	                            <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/images/my-profile-bg.jpg">
	                            <div class="carousel-caption">
	                            </div>
	                        </div>
	                        <div class="item">
	                            <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/images/my-profile-bg.jpg">
	                            <div class="carousel-caption">
	                            </div>
	                        </div>
	                    </div>
	                </div><!--/#carousel-example-generic-->
	            </div><!--/#carousel-container-->
			</div>
		</div>
</div>
